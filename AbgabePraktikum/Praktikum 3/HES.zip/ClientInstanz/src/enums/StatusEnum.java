package enums;

/**
 * Created with IntelliJ IDEA.
 * User: milena
 * Date: 19.05.13
 * Time: 14:24
 * To change this template use File | Settings | File Templates.
 */
public enum StatusEnum{
    ONLINE,
    OFFLINE,
    DEAD;
}
