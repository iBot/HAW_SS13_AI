package komponenten.RMIClientAdapter;

import java.rmi.RemoteException;

/**
 * Created with IntelliJ IDEA.
 * User: tobi
 * Date: 02.06.13
 * Time: 10:50
 */
public class NoRemoteAWKAvailableException extends RemoteException {
}
