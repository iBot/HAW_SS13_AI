package komponenten.AktiveRedundanz.dispatcher;

/**
 * Created with IntelliJ IDEA.
 * User: milena
 * Date: 22.05.13
 * Time: 10:55
 * To change this template use File | Settings | File Templates.
 */
public class noServerAvailableException extends Exception{

}
