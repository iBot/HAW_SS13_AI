package komponenten.AktiveRedundanz.dispatcher;



/**
 * Created with IntelliJ IDEA.
 * User: milena
 * Date: 19.05.13
 * Time: 13:53
 */
public interface IDispatcherManager {
    public int getZuVerwendendeSystemInstanzID() throws noServerAvailableException;
}
