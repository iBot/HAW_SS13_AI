package komponenten.AktiveRedundanz.dispatcher;

/**
 * Created with IntelliJ IDEA.
 * User: milena
 * Date: 22.05.13
 * Time: 10:51
 * To change this template use File | Settings | File Templates.
 */
public interface IDispatcherListener {
    void führeAktionAus(int Anzahl);
}
