package komponenten.AktiveRedundanz.monitor;

/**
 * Created with IntelliJ IDEA.
 * User: milena
 * Date: 19.05.13
 * Time: 14:04
 * To change this template use File | Settings | File Templates.
 */
public interface IMonitorListener {

    void führeAktionAus(long millisec);       //millisec/anzahl
}
