package main.komponenten.lager;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * User: Tobi
 * Date: 19.04.13
 * Time: 14:29
 */
public class ILagerEventTest {

    boolean wareReserviert = false;
    @Before
    public void setUp() throws Exception {

    }

    @After
    public void tearDown() throws Exception {

    }

    @Test
    public void testSchreibeFuerWarenReserviertEventEin() throws Exception {
//        LagerFassade lf = new LagerFassade();
////        Map<String, Integer> produktListe = new HashMap<>();
////        produktListe.put("PROD-1", 100);
////        produktListe.put("PROD-2", 50);
//        Date heute = new Date();
////        AngebotTyp angebot = new AngebotTyp("KUN-1", heute, new Date(heute.getTime() + (24L*60*60*1000)), new HashMap<>(produktListe));
//        AuftragTyp auftrag = new AuftragTyp("ANG-1", false, heute);
//        lf.schreibeFuerWarenReserviertEventEin(auftrag, new ILagerListener() {
//            @Override
//            public void fuehreAktionAus() {
//                wareReserviert = true;
//            }
//        });
//
//        lf.bucheWareneingang();

    }
}
