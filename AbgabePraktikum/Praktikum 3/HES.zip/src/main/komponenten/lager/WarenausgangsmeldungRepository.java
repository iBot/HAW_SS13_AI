package main.komponenten.lager;

import java.util.Date;
import java.util.UUID;

/**
 * Created with IntelliJ IDEA.
 * User: tobi
 * Date: 23.04.13
 * Time: 15:22
 * To change this template use File | Settings | File Templates.
 */
public class WarenausgangsmeldungRepository {

}
