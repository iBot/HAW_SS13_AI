package main.komponenten.einkauf;

import main.allgemeineTypen.transportTypen.BestellungTyp;
import main.allgemeineTypen.transportTypen.ProduktTyp;
import main.allgemeineTypen.transportTypen.WareneingangsmeldungTyp;

/**
 * User: Tobi
 * Date: 19.04.13
 * Time: 13:28
 */
class EinkaufLogik{

    public BestellungTyp bestelleProdukt(ProduktTyp produkt) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public void bestaetigeWareneingang(BestellungTyp bestellung, WareneingangsmeldungTyp wareneingangsmeldung) {
        //To change body of implemented methods use File | Settings | File Templates.
    }
}
