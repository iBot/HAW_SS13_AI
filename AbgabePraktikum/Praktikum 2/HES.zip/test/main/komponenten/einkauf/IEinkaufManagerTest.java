package main.komponenten.einkauf;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * User: Tobi
 * Date: 19.04.13
 * Time: 14:27
 */
public class IEinkaufManagerTest {
    @Before
    public void setUp() throws Exception {

    }

    @After
    public void tearDown() throws Exception {

    }

    @Test
    public void testBestelleProdukt() throws Exception {

    }

    @Test
    public void testBestaetigeWareneingang() throws Exception {

    }
}
