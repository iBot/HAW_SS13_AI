package main.hesStarter;

import main.allgemeineTypen.transportTypen.RechnungTyp;
import main.komponenten.buchhaltung.BuchhaltungFassade;
import main.komponenten.buchhaltung.IBuchhaltungListener;

/**
 * User: Tobi
 * Date: 19.04.13
 * Time: 12:14
 */
public class HESStarter {
    private static boolean bezahlt;
    public static void main(String[] args) {
        //TODO: Implement method body!
//        BuchhaltungFassade bf = new BuchhaltungFassade();
//        RechnungTyp rt = bf.erstelleRechnung(100, );
//        bf.schreibeFuerRechnungBezahltEventEin(rt.getRechnungsNr(), new IBuchhaltungListener() {
//            @Override
//            public void fuehreAktionAus() {
//                bezahlt = true;
//            }
//        });
//
//        bf.zahlungseingangBuchen(50.0, rt.getRechnungsNr());
//
//        System.out.print(bezahlt);
//
//        bf.zahlungseingangBuchen(60.0, rt.getRechnungsNr());
//
//        System.out.print(bezahlt);
    }
}
