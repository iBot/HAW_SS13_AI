package main.allgemeineTypen.transportTypen;

/**
 * User: Tobi
 * Date: 19.04.13
 * Time: 13:00
 */
public class BestellungTyp {
}
