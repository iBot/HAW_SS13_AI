package main.komponenten.einkauf;

import main.technik.persistenzManager.IPersistierbar;

/**
 * User: Tobi
 * Date: 19.04.13
 * Time: 13:31
 */
public class Bestellung implements IPersistierbar {
}
