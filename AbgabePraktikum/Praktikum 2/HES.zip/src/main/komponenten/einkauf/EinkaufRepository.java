package main.komponenten.einkauf;

import main.allgemeineTypen.transportTypen.BestellungTyp;
import main.allgemeineTypen.transportTypen.ProduktTyp;
import main.allgemeineTypen.transportTypen.WareneingangsmeldungTyp;

/**
 * User: Tobi
 * Date: 19.04.13
 * Time: 13:29
 */
class EinkaufRepository implements IEinkaufManager {
    @Override
    public BestellungTyp bestelleProdukt(ProduktTyp produkt) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public void bestaetigeWareneingang(BestellungTyp bestellung, WareneingangsmeldungTyp wareneingangsmeldung) {
        //To change body of implemented methods use File | Settings | File Templates.
    }
}
