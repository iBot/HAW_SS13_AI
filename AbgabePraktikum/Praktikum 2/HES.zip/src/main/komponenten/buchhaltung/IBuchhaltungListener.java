package main.komponenten.buchhaltung;

/**
 * User: Tobi
 * Date: 19.04.13
 * Time: 13:11
 */
public interface IBuchhaltungListener {
    public void fuehreAktionAus();
}
