package main.technik.persistenzManager;

/**
 * User: Tobi
 * Date: 19.04.13
 * Time: 12:41
 */

/**
 * Marker-Interface für persistierbare Klassen
 */
public interface IPersistierbar {
}
