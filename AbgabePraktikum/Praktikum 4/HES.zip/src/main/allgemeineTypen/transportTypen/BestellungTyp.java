package main.allgemeineTypen.transportTypen;

import java.io.Serializable;

/**
 * User: Tobi
 * Date: 19.04.13
 * Time: 13:00
 */
public class BestellungTyp implements Serializable {
}
