package main.komponenten.einkauf;

import main.technik.persistenzManager.IPersistierbar;

/**
 * User: Tobi
 * Date: 19.04.13
 * Time: 13:30
 */
class Orderbuch implements IPersistierbar {
}
