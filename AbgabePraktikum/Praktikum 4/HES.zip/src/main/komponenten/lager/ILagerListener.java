package main.komponenten.lager;

/**
 * User: Tobi
 * Date: 19.04.13
 * Time: 13:13
 */
public interface ILagerListener {
    public void fuehreAktionAus(Produkt produkt);
}
