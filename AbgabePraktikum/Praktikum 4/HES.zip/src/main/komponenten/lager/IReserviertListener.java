package main.komponenten.lager;

/**
 * Created with IntelliJ IDEA.
 * User: milena
 * Date: 02.05.13
 * Time: 15:53
 * To change this template use File | Settings | File Templates.
 */
public interface IReserviertListener {
    public void fuehreAktionAus();
}
