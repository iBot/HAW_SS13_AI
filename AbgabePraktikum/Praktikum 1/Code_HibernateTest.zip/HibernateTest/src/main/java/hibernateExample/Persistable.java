package hibernateExample;

/**
 * Created with IntelliJ IDEA.
 * User: Tobi
 * Date: 01.04.13
 * Time: 15:19
 * To change this template use File | Settings | File Templates.
 */
public interface Persistable {
}
