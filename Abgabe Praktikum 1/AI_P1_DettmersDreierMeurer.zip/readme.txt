AI Praktikum 1
##############

HES-Komponentenschnitt:
-----------------------
Der HES-Komponentenschnitt wurde mit VisualParadigm 10.1 erstellt (Datei HES_new.vpp) und enthält auch alle Schnittstellen-Spezifikationen.


OR-Mapping Beispiel:
--------------------
Der Code für das OR-Mapping-Beispiel mit Hibernate befindet sich in der Datei "Code_HibernateTest.zip".
Die verwendeten Bibliotheken sind nicht enthalten, da es sich um ein Maven-Projekt handelt, welches die von uns verwendeten Bibliotheken automatisch nachläd. Die dazu benötigte "pom.xml" ist im zip-Archiv enthalten.

Die Datei "mydb.db" enthält den Stand der Datenbank, nachdem das Programm einmal komplett durchlaufen und beendet wurde.


Präsentation:
-------------
"praktikum1.pdf" enthält die Präsentation, welche im Praktikum gezeigt wird.